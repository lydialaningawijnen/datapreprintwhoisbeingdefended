

#----------------------------------------
# FIGURE 1
#------------------------------------------
```{r}
#Create figure
library(ggplot2)
library(dplyr)
library(stringr)

if (!require(ggplot2)) install.packages("ggplot2")
if (!require(extrafont)) install.packages("extrafont", dependencies=TRUE)
if (!require(ggtext)) install.packages("ggtext")

library(ggplot2)
library(extrafont)
library(ggtext)
# Load the Times New Roman font
font_import(pattern = "times", prompt = FALSE)
loadfonts()

items_of_interest <- c("GBDEF1_W2", "GBDEF5_W2", "GBDEF6_W2", "GBDEF7_W2", "GASS11_W2", "GVDEF2_W2", "GVDEF4_W2", "GVDEF8_W2")
# Create a new data frame for plotting
plot_data <- svdat %>%
  summarise(across(all_of(items_of_interest), ~ sum(. == 1, na.rm = TRUE)))

# Reshape the data for plotting and adjust item names
plot_data_long <- tidyr::pivot_longer(plot_data, cols = everything(), names_to = "Item", values_to = "Count") %>%
  mutate(
    Item = str_replace(Item, "GASS11_W2", "Revenge"),
    Item = str_replace(Item, "GBDEF1_W2", "Stop bully"),
    Item = str_replace(Item, "GBDEF5_W2", "Push bully"),
    Item = str_replace(Item, "GBDEF6_W2", "Ask others"),
    Item = str_replace(Item, "GBDEF7_W2", "Got angry"),
    Item = str_replace(Item, "GVDEF2_W2", "Comfort victim"),
    Item = str_replace(Item, "GVDEF4_W2", "Being friendly"),
    Item = str_replace(Item, "GVDEF8_W2", "Distract victim")
  )

# Create the bar plot
ggplot(plot_data_long, aes(x = Item, y = Count, fill = Item)) +
  geom_bar(stat = "identity") +
  labs(title = "Prevalence of being defended in various ways",
       x = "Item",
       y = "Prevalence") +
  theme_minimal() +
  theme(text = element_text(family = "Times New Roman"),
        axis.text.x = element_text(angle = 45, hjust = 1)) +
  coord_flip() 


```


library(ggplot2)
library(dplyr)
library(stringr)
library(tidyr)

# Define the items of interest
items_of_interest <- c("GBDEF1_W2", "GBDEF5_W2", "GBDEF6_W2", "GBDEF7_W2", "GASS11_W2", "GVDEF2_W2", "GVDEF4_W2", "GVDEF8_W2")

# Compute counts and total responses for each item
plot_data <- svdat %>%
  summarise(across(all_of(items_of_interest), 
                   list(count = ~ sum(. == 1, na.rm = TRUE), 
                        total = ~ sum(!is.na(.))))) %>%
  pivot_longer(cols = everything(), 
               names_to = c("Item", ".value"), 
               names_sep = "_count|_total") %>%
  mutate(Percentage = (count / total) * 100)

# Adjust item names for better readability
plot_data <- plot_data %>%
  mutate(
    Item = str_replace(Item, "GASS11_W2", "Revenge"),
    Item = str_replace(Item, "GBDEF1_W2", "Stop bully"),
    Item = str_replace(Item, "GBDEF5_W2", "Push bully"),
    Item = str_replace(Item, "GBDEF6_W2", "Ask others"),
    Item = str_replace(Item, "GBDEF7_W2", "Got angry"),
    Item = str_replace(Item, "GVDEF2_W2", "Comfort victim"),
    Item = str_replace(Item, "GVDEF4_W2", "Being friendly"),
    Item = str_replace(Item, "GVDEF8_W2", "Distract victim")
  )

# Create the bar plot with percentages
ggplot(plot_data, aes(x = Item, y = Percentage, fill = Item)) +
  geom_bar(stat = "identity") +
  labs(title = "Prevalence of being defended in various ways",
       x = "Item",
       y = "Percentage") +
  theme_minimal() +
  theme(text = element_text(family = "Times New Roman"),
        axis.text.x = element_text(angle = 45, hjust = 1)) +
  coord_flip()

#proportion.
library(ggplot2)
library(dplyr)
library(stringr)
library(tidyr)

# Define the items of interest
items_of_interest <- c("GBDEF1_W2", "GBDEF5_W2", "GBDEF6_W2", "GBDEF7_W2", 
                       "GASS11_W2", "GVDEF2_W2", "GVDEF4_W2", "GVDEF8_W2")

# Compute counts and total responses for each item
plot_data <- svdat %>%
  summarise(across(all_of(items_of_interest), 
                   list(Count = ~ sum(. == 1, na.rm = TRUE), 
                        Total = ~ sum(!is.na(.))))) %>%
  pivot_longer(cols = everything(), 
               names_to = c("Item", ".value"), 
               names_pattern = "(.*)_(Count|Total)")  # Ensure proper column separation

# Compute percentage
plot_data <- plot_data %>%
  mutate(Percentage = (Count / Total) * 100)

# Rename items for better readability
plot_data <- plot_data %>%
  mutate(Item = recode(Item,
                       "GASS11_W2" = "Revenge",
                       "GBDEF1_W2" = "Stop bully",
                       "GBDEF5_W2" = "Push bully",
                       "GBDEF6_W2" = "Ask others",
                       "GBDEF7_W2" = "Got angry",
                       "GVDEF2_W2" = "Comfort victim",
                       "GVDEF4_W2" = "Being friendly",
                       "GVDEF8_W2" = "Distract victim"))

# Create the bar plot with percentages
ggplot(plot_data, aes(x = Item, y = Percentage, fill = Item)) +
  geom_bar(stat = "identity") +
  labs(title = "Percentage of victims who indicated to be defended in various ways",
       x = "Item",
       y = "Percentage") +
  theme_minimal() +
  theme(text = element_text(family = "Times New Roman"),
        axis.text.x = element_text(angle = 45, hjust = 1)) +
  coord_flip()

# Select and print the table with Item, Count, Total, and Percentage
percentage_table <- plot_data %>% select(Item, Count, Total, Percentage)
print(percentage_table)
# Select and print only the prevalence (percentage) values
prevalence_table <- plot_data %>% select(Item, Percentage)
print(prevalence_table)

# Select and print Item, Count, and Percentage
prevalence_table <- plot_data %>% select(Item, Count, Percentage)
print(prevalence_table)


#-----------------------------------
#TABLE 1
#-----------------------------------
```{r}
#pearson correlations can be used for continuous ones
#svdat$BDEFT <- as.numeric(svdat$BDEFT)
#svdat$STABVIC <- as.numeric(svdat$STABVIC)
#svdat$gender <- as.numeric(svdat$gender)
setsource()
cor_pearson <- cor.matrix(svdat[,c("BDEFT", "VDEFT", "STABVIC2", "VICT1", "VICT2",  
                                   "avg_nr_bulliesw1", "avg_nr_bullies", "FACTORN",   
                                   "givfr_w1", "pPNMP_W1_received", "DEFT1n", "bult1n", "SELFEF",  
                                   "HLPLS", "gender", "age2_w1" )],
                          sig = TRUE,
                          write = "Correlations_pearson_final.xlsx")

cor_kendall <- cor.matrix(svdat[,c("BDEFT", "VDEFT", "STABVIC2", "VICT1", "VICT2",  
                                   "avg_nr_bulliesw1", "avg_nr_bullies", "FACTORN",   
                                   "givfr_w1", "pPNMP_W1_received", "DEFT1n", "bult1n", "SELFEF",  
                                   "HLPLS", "gender", "age2_w1")],
                          method="kendall-b", sig = TRUE,
                          write = "Correlations_kendall_final.xlsx")

cor_spearman <- cor.matrix(svdat[,c("BDEFT", "VDEFT", "STABVIC2", "VICT1", "VICT2",  
                                    "avg_nr_bulliesw1", "avg_nr_bullies", "FACTORN",   
                                    "givfr_w1", "pPNMP_W1_received", "DEFT1n", "bult1n", "SELFEF",  
                                    "HLPLS", "gender", "age2_w1" )],
                           method="spearman",
                           sig = TRUE,
                           write = "Correlations_spearman_final.xlsx")

descript(svdat[,c("BDEFT", "VDEFT", "BDEFT1", "VDEFT1", "STABVIC2", "VICT1", "VICT2", "avg_nr_bulliesw1", "avg_nr_bullies", "FACTORN" , "givfr_w1", "pPNMP_W1_received", "DEFT1n",  "bult1n", "SELFEF", "HLPLS", "gender", "age2_w1" )])
```
